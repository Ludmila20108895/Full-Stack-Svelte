declare module 'frappe-charts'; // This module declaration is used to allow TypeScript to recognize the 'frappe-charts' module.

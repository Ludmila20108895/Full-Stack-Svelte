<footer class="has-text-centered has-text-grey mt-6 mb-4">
	<p>
		<strong>Explorer:</strong> All rights reserved.
	</p>
</footer>
